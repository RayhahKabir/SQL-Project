/*
				SQL Project Name : Inventory management System
					Trainee Name : Md Rayhan Kabir
					Trainee Name : PNTL 21
======================================================================================
Table of Contents: 
				 SELECTION 01: Created a Database.
				 SELECTION 02: Created Appropriate Tables with column definition related to the project.
				 SELECTION 03: ALTER, DROP AND MODIFY TABLES & COLUMNS.
				 SELECTION 04: View (Encrypt,Schemabinding).
				 SELECTION 05: CREATE STORED PROCEDURE.
				 SELECTION 06: CREATE FUNCTION.
				 SELECTION 07: CREATE TRIGGER (For/Alter TRIGGER).
				 SELECTION 08: CREATE TRIGGER (INSTEAD OF TRIGGER)
				 SELECTION 09: Join
====================================================================================
*/
					--SELECTION 01: Created a Database.
	   --==============================================================--
create database Project_01
on
(
	name='IMS Data',
	FileName='D:\IMSd\inventory_01.ldf',
	Size=20mb,
	maxsize=100mb,
	filegrowth=2%
)
log on
(
	name='IMS Data',
	FileName='D:\IMSd\inventory_02.ldf',
	Size=20mb,
	maxsize=100mb,
	filegrowth=5%
)
go
exec sp_helpdb 'Project_01'
go
--------------------------------------------------------------------------------------
							-- SELECTION 02
							---create table
							-----------------
create table product
(
	ProductID int primary key identity,
	ProductName Varchar(100) not null,
	Price money,
	Discount decimal (2,2) null 
)
go
alter table product  
drop column Quntity;
go
alter table product 
add  Quntity int;
go
alter table product 
add  Notification text;
go
----Check-----
create table supplier
(
	SupplierID int check(SupplierID like 'S-[0-9][0-9][0-9]' ),
	SupplierName Varchar(100) not null,
	ContactInformation TEXT,
	PaymentTerms Varchar(100)
)
go
---------------------------------------------------------------
create table costomar
(
	CostomarID int identity primary key,
	CoastomarName varchar (50) not null,
	ContactInformation TEXT
)
go
create table locations
(
	LocationID int Primary key identity,
	LocationName varchar(100),
	Adderss varchar(50),
	Contuct Varchar(100)
)
go
--Table with PRIMARY KEY & FOREIGN KEY
create table seles
(
	SelesID int identity Primary key,
	SeleDate datetime default getdate(),
	Costomar int references costomar(CostomarID),
	TotalSele money
)
go
create table seleDetails
(
	SeleDelailsID int identity primary key,
	Sele int references seles(SelesID),
	Product int references product(ProductID),
	UnitPrice money,
	TotalPrice money,
	Quntity int
)
go
create table inventoryTransactions 
(
	TranseactionID int identity primary key,
	Product int references product(ProductID),
	Locations int references locations(LocationID),
	TarnseactionDate datetime,
	Quntity int
)
go
create table notifications
(
	NotifictionID Int identity primary key,
	Product int references product(ProductID),
	NotificationDate DateTime,
	NotificatioMassage Text,

)
go
/*
				SELECTION 03
				   ALTER
*/
ALTER TABLE costomer
add  ContuctNumder varchar(20);
go
---------------------------------------------------------------------
/*
				SELECTION 04
				   View
*/
create view vproduct
as
select ProductID,ProductName,Price,Discount,Quntity
from product;
go
select * from vproduct
go
select * from product
go
/*
				Encrypt view
*/
Alter view vproduct 
with encryption
as
select ProductID ,ProductName,Price,Discount,Quntity 
from vproduct
go
exec sp_helptext vproduct
go
select * from vproduct
go
/*
				Schemabinding
*/
alter view vproduct
with encryption,schemabinding
as
select ProductID,ProductName,Price,Discount,Quntity 
from dbo.vproduct;
go
drop table product
go
/*
				SELECTION 07
		      Trigger(For/After)
		       Update Or delete
*/
create trigger trproduct
on product
for update,Delete
as
begin
	print 'Not possible Update or Delete'
	Rollback transaction
end
go
drop trigger trproduct
go
---------------------------------------------------------------------
/*
				SELECTION 07
		       Trigger(Update)
		        
*/
CREATE TRIGGER trproduct
ON product
AFTER INSERT
AS
BEGIN
    DECLARE @i INT,
            @n varchar
    
    SELECT @i=ProductID,n@=ProductName FROM inserted
    
    UPDATE vproduct
    SET NotificationMessage=NotificationMessage + @n
    WHERE Product = @i
END
GO


---------------------------------------------------------------------
/*
				SELECTION 07
		      Trigger(Instead)
*/

---------------------------------------------------------------------
/*
				SELECTION 09
				    Joi
*/
select * from product

select ProductID, ProductName, Price, Discount, Quntity�from�product
go
select * from supplier
select SupplierID, SupplierName, ContactInformation,PaymentTerms�from�supplier
go
select * from locations

select LocationID, LocationName, Adderss,Contuct �from�locations
go
select * from costomar

select CostomarID, CoastomarName, ContactInformation�from�costomar
go
select r.SelesID, r.SeleDate, r.Costomar, c.CoastomarName, r.TotalSele  
from seles r
inner join costomar c on r.Costomar�=�c.CostomarID
go
select sd.SeleDelailsID, sd.Sele, s.TotalSele,  sd.Product, p.ProductName, sd.UnitPrice, sd.TotalPrice, sd.Quntity
from seleDetails sd
inner join seles s on sd.Sele = s.SelesID
inner join product p on sd.Product�=�p.ProductID
go
select t.TranseactionID, t.Product, p.ProductName, t.Locations, l.LocationName,t.TarnseactionDate, t.Quntity
from inventoryTransactions t
inner join locations l on t.Locations = l.LocationID
inner join product p on t.Product�=�p.ProductID
go
select n.NotifictionID, n.Product, p.ProductName, n.NotificationDate, n.NotificatioMassage
from notifications n
inner join product p on n.Product�=�p.ProductID
go
